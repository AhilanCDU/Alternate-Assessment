import os
import pandas as pd
import sys

# Set the folder path where data is stored
folder_path = "/Users/ahilan/Desktop/Software/Software Now/HIT137 - Alternate Assessment/question_2/temperature_data"

# Check folder exists
if not os.path.exists(folder_path):
    print(f"Error: Folder '{folder_path}' does not exist. Please check path.")
    sys.exit(1)

# Gather all data in folder
csv_files = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith(".csv")]

# Ensure that data exists in folder
if not csv_files:
    print("Error: No data found in 'temperature_data'.")
    sys.exit(1)

# Debugging: Print found data
print("Found temperature data:", csv_files)

# Load and combine all data
dfs = []
for file in csv_files:
    try:
        df = pd.read_csv(file)
        
        # Debugging: Print column names
        print(f"Processing {file}, columns: {df.columns.tolist()}")

        # Check columns exist
        required_columns = {"STATION_NAME", "STN_ID", "LAT", "LON",
                            "January", "February", "March", "April", "May", "June",
                            "July", "August", "September", "October", "November", "December"}
        if not required_columns.issubset(df.columns):
            print(f"Skipping {file} - has no required columns.")
            continue
        
        dfs.append(df)

    except Exception as e:
        print(f"File reading error {file}: {e}")

# Check if any data loaded
if not dfs:
    print("Error: No valid data processed.")
    sys.exit(1)

# Combine all years' data
data = pd.concat(dfs, ignore_index=True)

# 1. Calculate average temperature for each month (ignore zeros)
monthly_avg_temp = data.iloc[:, 4:].replace(0, pd.NA).mean(skipna=True)

# Convert for correct saving format
monthly_avg_temp_df = monthly_avg_temp.reset_index()
monthly_avg_temp_df.columns = ["Month", "Average Temperature"]

# 2. Calculate average temperatures for each season
seasonal_mapping = {
    "Summer": ["December", "January", "February"],
    "Autumn": ["March", "April", "May"],
    "Winter": ["June", "July", "August"],
    "Spring": ["September", "October", "November"]
}

seasonal_avg_temp = {season: data[months].replace(0, pd.NA).mean().mean(skipna=True) for season, months in seasonal_mapping.items()}
seasonal_avg_temp_df = pd.DataFrame.from_dict(seasonal_avg_temp, orient="index", columns=["Average Temperature"])

# 3. Find station(s) with largest range of temperatures
data["Temp_Range"] = data.iloc[:, 4:].max(axis=1) - data.iloc[:, 4:].min(axis=1)
largest_temp_range = data[data["Temp_Range"] == data["Temp_Range"].max()][["STATION_NAME", "Temp_Range"]]

# 4. Find warmest and coolest stations (yearly average)
data["Yearly_Avg_Temp"] = data.iloc[:, 4:].replace(0, pd.NA).mean(axis=1, skipna=True)
warmest_station = data[data["Yearly_Avg_Temp"] == data["Yearly_Avg_Temp"].max()][["STATION_NAME", "Yearly_Avg_Temp"]]
coolest_station = data[data["Yearly_Avg_Temp"] == data["Yearly_Avg_Temp"].min()][["STATION_NAME", "Yearly_Avg_Temp"]]

# **Check output folder correct**
output_folder = "/Users/ahilan/Desktop/Software/Software Now/HIT137 - Alternate Assessment/question_2/"

# Debug: Print where files are to be saved
print(f"Saving files to: {output_folder}")

# Save output files (`index=False` avoiding extra column)
monthly_avg_temp_df.to_csv(os.path.join(output_folder, "average_temp_per_month.txt"), header=True, index=False)
seasonal_avg_temp_df.to_csv(os.path.join(output_folder, "average_temp.txt"), header=True, index=False)
largest_temp_range.to_csv(os.path.join(output_folder, "largest_temp_range_station.txt"), header=True, index=False)

with open(os.path.join(output_folder, "warmest_and_coolest_station.txt"), "w") as f:
    f.write("Warmest Station(s):\n")
    warmest_station.to_csv(f, header=True, index=False)
    f.write("\nCoolest Station(s):\n")
    coolest_station.to_csv(f, header=True, index=False)

print("\n The analysis has been completed. Results saved to:")
print(" average_temp_per_month.txt")
print(" average_temp.txt")
print(" largest_temp_range_station.txt")
print(" warmest_and_coolest_station.txt")

import turtle

def draw_branch(t, branch_length, left_angle, right_angle, depth, reduction_factor):
    if depth == 0:
        return
    
    # Set the colour based on depth
    if depth > 2:
        t.pencolor("brown")  # Brown trunk
    else:
        t.pencolor((0, depth / 10, 0))  # Darker green for deep branches
    
    t.forward(branch_length)
    
    # Left branch
    t.left(left_angle)
    draw_branch(t, branch_length * reduction_factor, left_angle, right_angle, depth - 1, reduction_factor)
    t.right(left_angle)
    
    # Right branch
    t.right(right_angle)
    draw_branch(t, branch_length * reduction_factor, left_angle, right_angle, depth - 1, reduction_factor)
    t.left(right_angle)
    
    t.backward(branch_length)

def main():
    # Obtain user input for various parameters
    left_angle = float(input("Enter left branch angle: "))
    right_angle = float(input("Enter right branch angle: "))
    start_length = float(input("Enter starting branch length: "))
    depth = int(input("Enter recursion depth: "))
    reduction_factor = float(input("Enter branch length reduction factor (e.g., 0.7 for 70%): "))
    
    # Turtle setup
    screen = turtle.Screen()
    screen.bgcolor("white")
    t = turtle.Turtle()
    t.speed(0)
    t.left(90)
    t.up()
    t.goto(0, -200)
    t.down()
    
    # Trunk color
    t.pensize(2)
    t.pencolor("brown")
    
    # Tree drawing
    draw_branch(t, start_length, left_angle, right_angle, depth, reduction_factor)
    
    # Wait for user to close the window
    screen.mainloop()

if __name__ == "__main__":
    main()
